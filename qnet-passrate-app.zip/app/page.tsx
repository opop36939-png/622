import PassRateExplorer from "./components/PassRateExplorer";

export default function Home() {
  return (
    <main className="flex-1 bg-paper bg-paper-texture">
      <div className="mx-auto max-w-5xl px-5 py-10 sm:py-14">
        <header className="mb-10 animate-fade-up">
          <p className="text-xs tracking-[0.25em] text-[var(--gold)] font-semibold mb-3">
            Q-NET OPEN API · 한국산업인력공단
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[var(--navy-deep)] leading-tight">
            국가기술자격 합격률 조회
          </h1>
          <p className="mt-3 text-sm sm:text-base text-[var(--ink-soft)] max-w-2xl leading-relaxed">
            등급과 기준년도를 선택하면, 종목별 응시자수·합격자수·합격률을
            한눈에 확인할 수 있습니다. 공공데이터포털에서 제공하는 큐넷
            합격률 데이터를 그대로 가져옵니다.
          </p>
        </header>

        <PassRateExplorer />

        <footer className="mt-16 pt-6 border-t border-[var(--line)] text-xs text-[var(--ink-soft)] flex flex-wrap gap-x-4 gap-y-1">
          <span>데이터 출처: 한국산업인력공단(Q-net)</span>
          <span>제공: 공공데이터포털</span>
        </footer>
      </div>
    </main>
  );
}
