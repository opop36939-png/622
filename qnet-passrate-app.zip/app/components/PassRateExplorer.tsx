"use client";

import { useMemo, useState } from "react";
import type { PassRateItem } from "../api/pass-rate/route";

// 큐넷 활용가이드 문서에 명시된 등급코드 표
const GRADE_OPTIONS: { code: string; label: string }[] = [
  { code: "10", label: "기술사" },
  { code: "20", label: "기능장" },
  { code: "30", label: "기사" },
  { code: "31", label: "산업기사" },
  { code: "32", label: "1급" },
  { code: "33", label: "2급" },
  { code: "40", label: "기능사" },
];

const currentYear = new Date().getFullYear();
// 큐넷 데이터는 보통 전년도까지 갱신되어 있어 기본값을 작년으로 설정
const YEAR_OPTIONS = Array.from({ length: 15 }, (_, i) => String(currentYear - 1 - i));

type SortKey = "passRate" | "recptNoCnt" | "examPassCnt";

export default function PassRateExplorer() {
  const [grdCd, setGrdCd] = useState("31");
  const [baseYY, setBaseYY] = useState(YEAR_OPTIONS[0]);
  const [keyword, setKeyword] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("passRate");
  const [sortDesc, setSortDesc] = useState(true);

  const [items, setItems] = useState<PassRateItem[]>([]);
  const [totalCount, setTotalCount] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  async function handleSearch() {
    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const params = new URLSearchParams({
        grdCd,
        baseYY,
        numOfRows: "300",
        pageNo: "1",
      });
      const res = await fetch(`/api/pass-rate?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setItems([]);
        setTotalCount(null);
        setError(data.error ?? "데이터를 불러오지 못했습니다.");
        return;
      }

      setItems(data.items);
      setTotalCount(data.totalCount);
    } catch (err) {
      console.error(err);
      setError("네트워크 오류로 데이터를 불러오지 못했습니다.");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  const filteredAndSorted = useMemo(() => {
    const filtered = keyword.trim()
      ? items.filter((item) => item.jmFldNm.includes(keyword.trim()))
      : items;

    const parsedRate = (item: PassRateItem) =>
      parseFloat(item.passRate.replace("%", "")) || 0;

    const sorted = [...filtered].sort((a, b) => {
      let diff = 0;
      if (sortKey === "passRate") diff = parsedRate(a) - parsedRate(b);
      if (sortKey === "recptNoCnt") diff = a.recptNoCnt - b.recptNoCnt;
      if (sortKey === "examPassCnt") diff = a.examPassCnt - b.examPassCnt;
      return sortDesc ? -diff : diff;
    });

    return sorted;
  }, [items, keyword, sortKey, sortDesc]);

  function toggleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDesc((prev) => !prev);
    } else {
      setSortKey(key);
      setSortDesc(true);
    }
  }

  return (
    <section className="animate-fade-up">
      {/* 검색 조건 카드 */}
      <div className="seal-border bg-[var(--card)] rounded-sm p-5 sm:p-6 shadow-sm">
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-4">
          <label className="block">
            <span className="block text-xs font-semibold text-[var(--ink-soft)] mb-1.5">
              등급
            </span>
            <select
              value={grdCd}
              onChange={(e) => setGrdCd(e.target.value)}
              className="w-full border border-[var(--line)] rounded-sm px-3 py-2.5 bg-white text-[var(--ink)] focus:outline-none focus:ring-2 focus:ring-[var(--navy)] focus:border-[var(--navy)]"
            >
              {GRADE_OPTIONS.map((g) => (
                <option key={g.code} value={g.code}>
                  {g.label}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="block text-xs font-semibold text-[var(--ink-soft)] mb-1.5">
              기준년도
            </span>
            <select
              value={baseYY}
              onChange={(e) => setBaseYY(e.target.value)}
              className="w-full border border-[var(--line)] rounded-sm px-3 py-2.5 bg-white text-[var(--ink)] focus:outline-none focus:ring-2 focus:ring-[var(--navy)] focus:border-[var(--navy)]"
            >
              {YEAR_OPTIONS.map((y) => (
                <option key={y} value={y}>
                  {y}년
                </option>
              ))}
            </select>
          </label>

          <div className="flex items-end">
            <button
              onClick={handleSearch}
              disabled={loading}
              className="w-full sm:w-auto px-6 py-2.5 bg-[var(--navy-deep)] text-white text-sm font-semibold rounded-sm hover:bg-[var(--navy)] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "조회 중..." : "조회하기"}
            </button>
          </div>
        </div>
      </div>

      {/* 결과 영역 */}
      <div className="mt-6">
        {error && (
          <div className="border border-[var(--seal)]/30 bg-[var(--seal)]/5 text-[var(--seal)] text-sm rounded-sm px-4 py-3">
            {error}
          </div>
        )}

        {!error && hasSearched && !loading && items.length === 0 && (
          <div className="text-center py-16 text-[var(--ink-soft)] text-sm">
            조회된 데이터가 없습니다. 등급이나 연도를 변경해 다시 시도해보세요.
          </div>
        )}

        {!error && items.length > 0 && (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <p className="text-sm text-[var(--ink-soft)]">
                총{" "}
                <span className="font-semibold text-[var(--ink)]">
                  {totalCount?.toLocaleString() ?? filteredAndSorted.length}
                </span>
                건 중{" "}
                <span className="font-semibold text-[var(--ink)]">
                  {filteredAndSorted.length}
                </span>
                건 표시
              </p>
              <input
                type="text"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                placeholder="종목명 검색 (예: 정보처리)"
                className="border border-[var(--line)] rounded-sm px-3 py-1.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[var(--navy)] focus:border-[var(--navy)] w-full sm:w-56"
              />
            </div>

            <div className="overflow-x-auto seal-border rounded-sm bg-[var(--card)]">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-[var(--navy-deep)] text-white text-left">
                    <th className="px-4 py-3 font-semibold whitespace-nowrap">
                      종목명
                    </th>
                    <th className="px-4 py-3 font-semibold whitespace-nowrap">
                      구분
                    </th>
                    <th className="px-4 py-3 font-semibold whitespace-nowrap">
                      회차
                    </th>
                    <th
                      className="px-4 py-3 font-semibold whitespace-nowrap cursor-pointer select-none"
                      onClick={() => toggleSort("recptNoCnt")}
                    >
                      응시자수 {sortKey === "recptNoCnt" && (sortDesc ? "▼" : "▲")}
                    </th>
                    <th
                      className="px-4 py-3 font-semibold whitespace-nowrap cursor-pointer select-none"
                      onClick={() => toggleSort("examPassCnt")}
                    >
                      합격자수 {sortKey === "examPassCnt" && (sortDesc ? "▼" : "▲")}
                    </th>
                    <th
                      className="px-4 py-3 font-semibold whitespace-nowrap cursor-pointer select-none"
                      onClick={() => toggleSort("passRate")}
                    >
                      합격률 {sortKey === "passRate" && (sortDesc ? "▼" : "▲")}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAndSorted.map((item, idx) => {
                    const rate = parseFloat(item.passRate.replace("%", "")) || 0;
                    return (
                      <tr
                        key={`${item.jmFldNm}-${item.implSeq}-${item.examTypCcd}-${idx}`}
                        className="border-t border-[var(--line)] hover:bg-[var(--paper)] transition-colors"
                      >
                        <td className="px-4 py-2.5 font-medium text-[var(--ink)]">
                          {item.jmFldNm}
                        </td>
                        <td className="px-4 py-2.5 text-[var(--ink-soft)]">
                          {item.examTypCcd}
                        </td>
                        <td className="px-4 py-2.5 text-[var(--ink-soft)]">
                          {item.implYy}-{item.implSeq}
                        </td>
                        <td className="px-4 py-2.5 text-right tabular-nums">
                          {item.recptNoCnt.toLocaleString()}
                        </td>
                        <td className="px-4 py-2.5 text-right tabular-nums">
                          {item.examPassCnt.toLocaleString()}
                        </td>
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-2 min-w-[120px]">
                            <div className="flex-1 h-1.5 bg-[var(--line)] rounded-full overflow-hidden">
                              <div
                                className="h-full bg-[var(--gold)]"
                                style={{ width: `${Math.min(rate, 100)}%` }}
                              />
                            </div>
                            <span className="text-xs font-semibold tabular-nums w-12 text-right">
                              {item.passRate}
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}

        {!hasSearched && !loading && (
          <div className="text-center py-16 text-[var(--ink-soft)] text-sm">
            등급과 기준년도를 선택한 뒤 &ldquo;조회하기&rdquo;를 눌러주세요.
          </div>
        )}
      </div>
    </section>
  );
}
